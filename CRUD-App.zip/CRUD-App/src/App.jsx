import React, { useState } from 'react';

const CrudComponent = () => {
  const [items, setItems] = useState([]);
  const [formData, setFormData] = useState({ id: null, name: '' });
  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleAdd = () => {
    const newItem = { id: Date.now(), name: formData.name };
    setItems([...items, newItem]);
    setFormData({ id: null, name: '' });
  };

  const handleEdit = (id) => {
    const itemToEdit = items.find((item) => item.id === id);
    setFormData(itemToEdit);
    setIsEditing(true);
  };

  const handleUpdate = () => {
    const updatedItems = items.map((item) =>
      item.id === formData.id ? { ...item, name: formData.name } : item
    );
    setItems(updatedItems);
    setFormData({ id: null, name: '' });
    setIsEditing(false);
  };

  const handleDelete = (id) => {
    const filteredItems = items.filter((item) => item.id !== id);
    setItems(filteredItems);
  };

  return (
    <div className="container d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
      <div className="card shadow-lg p-4" style={{ maxWidth: '500px', width: '100%' }}>
        <h2 className="text-center mb-4 text-primary">---:CRUD Operations:----</h2>
        
        <div className="mb-4">
          <div className="input-group">
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleInputChange}
              className="form-control"
              placeholder="Enter item name"
            />
            <button
              onClick={isEditing ? handleUpdate : handleAdd}
              className={`btn ${isEditing ? 'btn-warning' : 'btn-primary'}`}
            >
              {isEditing ? 'Update' : 'Add'}
            </button>
          </div>
        </div>

        <div className="card mt-4">
          <div className="card-header bg-dark text-white">
            <h4 className="mb-0">Items List</h4>
          </div>
          <ul className="list-group list-group-flush">
            {items.length > 0 ? (
              items.map((item) => (
                <li
                  key={item.id}
                  className="list-group-item d-flex justify-content-between align-items-center"
                >
                  {item.name}
                  <div>
                    <button
                      className="btn btn-sm btn-success me-2"
                      onClick={() => handleEdit(item.id)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      onClick={() => handleDelete(item.id)}
                    >
                      Delete
                    </button>
                  </div>
                </li>
              ))
            ) : (
              <li className="list-group-item text-center">No items available</li>
            )}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default CrudComponent;

